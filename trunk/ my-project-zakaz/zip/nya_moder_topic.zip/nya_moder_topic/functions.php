<?php

/**
 * moder_topic 
 *
 * @copyright Copyright (C) 2011 PunBB
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package moder_topic
 */

if (!defined('FORUM'))
	die();

// Generate cache file
function moder_topic_generate_cache()
{
	global $forum_db;

	$query = array(
		'SELECT'	=>	'o.topic_id, o.user_id, u.username',
		'FROM'		=>	'officer AS o',
		'JOINS'		=>	array(
			array(
				'LEFT JOIN'	=>	'users AS u',
				'ON'		=>	'o.user_id = u.id'
			)
		)
	);
	$result = $forum_db->query_build($query) or error(__FILE__, __LINE__);

	$moder_topic = array();
	$moder_topic['cached'] = time();
	if ($forum_db->num_rows($result) > 0)
	{
		$moder_topic['user_id'] = $moder_topic['username'] = array();
		//Process all topics
		while ($cur_post = $forum_db->fetch_assoc($result))
		{			
			if (!isset($moder_topic['user_id'][$cur_post['topic_id']]))
				$moder_topic['user_id'][$cur_post['topic_id']] = array();
			$moder_topic['user_id'][$cur_post['topic_id']][] = $cur_post['user_id'];
			if (!isset($moder_topic['username'][$cur_post['topic_id']]))
				$moder_topic['username'][$cur_post['topic_id']] = array();
			$moder_topic['username'][$cur_post['topic_id']][$cur_post['user_id']] = $cur_post['username'];
		}
	}

	// Output pun tags as PHP code
	$fh = @fopen(FORUM_CACHE_DIR.'cache_moder_topic.php', 'wb');
	if (!$fh)
		error('Unable to write moder post cache file to cache directory. Please make sure PHP has write access to the directory \'cache\'.', __FILE__, __LINE__);
	fwrite($fh, '<?php'."\n\n".'if (!defined(\'MODER_POST_LOADED\')) define(\'MODER_POST_LOADED\', 1);'."\n\n".'$moder_topic = '.var_export($moder_topic, true).';'."\n\n".'?>');
	fclose($fh);
}

// Get array of officer from input string
function moder_topic_parse_string($text)
{
	global $lang_moder_topic;

	if (utf8_strlen(forum_trim($text)) > 100)
		message($lang_moder_topic['Count error']);

	// Remove symbols and multiple whitespace
	$text = preg_replace('/[\'\^\$&\(\)<>`"\|@_\?%~\+\[\]{}:=\/#\\\\;!\*\.]+/', '', preg_replace('/[\s]+/', ' ', $text));
	$text = censor_words($text);
	$text = explode(',', $text);

	$results = array();
	foreach ($text as $off)
	{
		$tmp_off = utf8_trim($off);
		if (!empty($tmp_off))
			$results[] = utf8_substr_replace($tmp_off, '', 50);
	}

	return array_unique($results);
}

// Remove from topic 
function moder_topic_remove_topic($topic_id)
{
	global $forum_db;

	$query = array(
		'DELETE'	=> 'officer',
		'WHERE'		=> 'topic_id = '.$topic_id
	);
	$forum_db->query_build($query) or error(__FILE__, __LINE__);
}

function moder_topic_add_new($user, $topic_id)
{
	global $forum_db;
	
	if ($user > 0)
	{
		$moder_topic_query = array(
			'INSERT'	=> 'topic_id, user_id',
			'INTO'		=> 'officer',
			'VALUES'	=> $topic_id.', '.$user
		);
		$forum_db->query_build($moder_topic_query) or error(__FILE__, __LINE__);	
	}
	else
	{
		$query_user = array(
			'SELECT'	=>	'u.id',
			'FROM'		=>	'users AS u',
			'WHERE'		=> 	'u.username = \''.$user.'\''
		);
		$result = $forum_db->query_build($query_user) or error(__FILE__, __LINE__);
		if ($forum_db->num_rows($result) > 0)
		{
			list($user) = $forum_db->fetch_row($result);
			$moder_topic_query = array(
				'INSERT'	=> 'topic_id, user_id',
				'INTO'		=> 'officer',
				'VALUES'	=> $topic_id.', '.$user
			);
			$forum_db->query_build($moder_topic_query) or error(__FILE__, __LINE__);	
		}
	}
}


function compare_post($tag_info1, $tag_info2)
{
	return strcmp($tag_info1['tag'], $tag_info2['tag']);
}

?>
