<?php
/**
 * Default SEF URL scheme.
 *
 */

$forum_url['search_responsible'] = 'search.php?action=show_responsible&amp;user_id=$1';

?>