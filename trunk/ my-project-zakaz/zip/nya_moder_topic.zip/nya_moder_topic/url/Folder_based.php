<?php
/**
 * Folder based SEF URL scheme.
 *
 */

$forum_url['search_responsible'] = 'search/responsible/$1/';

?>