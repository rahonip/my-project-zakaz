<?php

/**
 * Lang file
 *
 * @copyright Copyright (C) 2009 PunBB
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package nya_moder_topic
 */

if (!defined('FORUM')) die();

$lang_nya_moder_topic = array(
	'Allow moder'			=>	'Модерирование тем',
	'Allow moder label'		=>	'Разрешить модераторам назначать ответственных за тему.',
	'View enable'			=>	'Отвественные в теме',
	'View enable label'		=>	'Показывать в сообщениях ответственных за тему.',
	'jQuery enable'			=>	'АвтоПоиск',
	'jQuery enable label'	=>	'Использовать АвтоПоиск куратора среди пользователей форума. jQuery должен быть установлен',
	'Silent enable'			=>	'Редактирование',
	'Silent enable label'	=>	'Отображает «Отредактировано…» при изменении сообщения куратором',
	'Topic officer' 		=>	'Куратор темы',
	'Topic officers' 		=>	'Отвественные за тему ',
	'Topic officer crumbs' 	=>	' <b>Отвественные за тему: %s.</b>',
	'View your responsible'	=>	'Показать темы, за которые вы отвечаете',
	'View user responsible'	=>	'Показать темы, за которые отвечает пользователь',
);

?>
