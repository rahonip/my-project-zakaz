<?php

/**
 * Lang file
 *
 * @copyright Copyright (C) 2009 PunBB
 * @license http://www.gnu.org/licenses/gpl.html GPL version 2 or higher
 * @package nya_moder_topic
 */

if (!defined('FORUM')) die();

$lang_nya_moder_topic = array(
	'Allow moder'			=>	'Moderate Topic',
	'Allow moder label'		=>	'Allow moders check officer.',
	'View enable' 			=> 	'Responsibility in the subject line',
	'View enable label' 	=> 	'Display messages in charge of the subject.',
	'jQuery enable'			=>	'Autocomplete ',
	'jQuery enable label'	=>	'Use Autocomplete responsible for the topiс. jQuery to be installed.',
	'Silent enable'			=>	'Silent edit',
	'Silent enable label'	=>	'Display "Last edited by…" edit for Responsible.',
	'Topic officer' 		=>	'Responsible for the topic',
	'Topic officers' 		=>	'Responsible for the topics',
	'Topic officer crumbs' 	=>	' <b>Responsible for the topic: %s.</b>',
	'View your responsible'	=>	'Display topics for which you are responsible',
	'View user responsible'	=>	'Display topics under the responsibility of the user',
);

?>
