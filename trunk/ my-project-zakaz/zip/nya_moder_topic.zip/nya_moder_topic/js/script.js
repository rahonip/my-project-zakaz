$(function() {
	function split( val ) {
		return val.split( /,\s*/ );
	}
	function extractLast( term ) {
		return split( term ).pop();
	}
	$("input[name='post_officer']").autocomplete({
		source: function( request, response ) {
			$.getJSON( j_url + "/auto.php", {
				term: extractLast( request.term )
			}, response );
		},
		focus: function() {
			return false;
		},
		select: function( event, ui ) {
				var terms = split( this.value );
				terms.pop();
				terms.push( ui.item.value );
				terms.push( "" );
				this.value = terms.join( ", " );
				return false;
			}
	});
});
$(document).ready(function() {
		var nya = $("input[name='post_officer']");
		var vtx = nya.val();
		if (vtx.length > 0) vtx += ", ";
		nya.val(vtx);
});
