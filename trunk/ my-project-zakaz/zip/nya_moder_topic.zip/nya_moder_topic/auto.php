<?php
header("Content-type: text/plain; charset=utf-8");

$q = strtolower($_GET["term"]);
if (!$q) return;

function array_to_json( $array ){

    if( !is_array( $array ) ){
        return false;
    }

    $associative = count( array_diff( array_keys($array), array_keys( array_keys( $array )) ));
    if( $associative ){

        $construct = array();
        foreach( $array as $key => $value ){

            // We first copy each key/value pair into a staging array,
            // formatting each key and value properly as we go.

            // Format the key:
            if( is_numeric($key) ){
                $key = "key_$key";
            }
            $key = "\"".addslashes($key)."\"";

            // Format the value:
            if( is_array( $value )){
                $value = array_to_json( $value );
            } else if( !is_numeric( $value ) || is_string( $value ) ){
                $value = "\"".addslashes($value)."\"";
            }

            // Add to staging array:
            $construct[] = "$key: $value";
        }

        // Then we collapse the staging array into the JSON form:
        $result = "{ " . implode( ", ", $construct ) . " }";

    } else { // If the array is a vector (not associative):

        $construct = array();
        foreach( $array as $value ){

            // Format the value:
            if( is_array( $value )){
                $value = array_to_json( $value );
            } else if( !is_numeric( $value ) || is_string( $value ) ){
                $value = "'".addslashes($value)."'";
            }

            // Add to staging array:
            $construct[] = $value;
        }

        // Then we collapse the staging array into the JSON form:
        $result = "[ " . implode( ", ", $construct ) . " ]";
    }

    return $result;
}

if (!defined('FORUM_ROOT')) 
	define('FORUM_ROOT', '../../');
require FORUM_ROOT.'config.php';
require FORUM_ROOT.'include/dblayer/common_db.php';

	$query = array(
		'SELECT'	=>	'u.id, u.username',
		'FROM'		=>	'users AS u',
		'WHERE'		=>	'username like "%'.$q.'%"'
	);
	$result_sql = $forum_db->query_build($query);
	$result = array();
	if ($forum_db->num_rows($result_sql) > 0)
	{
		while ($cur_post = $forum_db->fetch_assoc($result_sql))
		{
			array_push($result, array("id"=>$cur_post['id'], "label"=>$cur_post['username'], "value" => $cur_post['id']));
		}
	}

echo array_to_json($result);

?>
