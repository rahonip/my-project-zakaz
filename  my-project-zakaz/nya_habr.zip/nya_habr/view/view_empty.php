		<fieldset class="frm-group group<?php echo ++App::$forum_page['group_count'] ?>">
			<p><?php echo App::$lang['No habr'] ?></p>
		</fieldset>
