	<div class="main-head">
		<h2 class="hn"><span><?php echo $heading ?></span></h2>
	</div>
	<div class="main-content main-frm">
<?php echo $content ?>	
	</div>
	<div class="main-foot">
		<h2 class="hn"><span><span class="item-info"></span></span></h2>
	</div>
	
		
