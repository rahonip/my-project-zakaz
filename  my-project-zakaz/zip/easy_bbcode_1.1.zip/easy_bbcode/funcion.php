<?php
function bbcodes_cache()
{
	global $forum_db,$base_url;

	if(!file_exists(FORUM_ROOT."/cache/cache_bbcode.php"))
	{
		$mode = "x";
	}
	else
	{
		$mode = "w";
	}

	$consulta=$forum_db->query("SELECT * FROM ".$forum_db->prefix."bbcodes") or error(__FILE__, __LINE__);
	while($resultado=$forum_db->fetch_assoc($consulta))
	{		
		$bbcodes.="\$bbcodes_cache['".$resultado['cid']."']['exregular']='#".$resultado['exregular']."#i';\n\$bbcodes_cache['".$resultado['cid']."']['reemplazo']='".str_replace("'", "\'", $resultado['reemplazo'])."';\n\$bbcodes_cache['".$resultado['cid']."']['active']='".$resultado['active']."';\n";
	}	
	$wbbcache = "<"."?php\n/*Easy BBcode cache */\n$bbcodes\n?".">";
	$file = @fopen(FORUM_ROOT."/cache/cache_bbcode.php", $mode);
	@fwrite($file, $wbbcache);
	@fclose($file);
	redirect("".$base_url."/admin/settings.php?section=bbcodes&result=sus", "ok");
}
?>