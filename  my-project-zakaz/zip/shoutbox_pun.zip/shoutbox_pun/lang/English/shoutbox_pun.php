<?php
/**
* shoutbox_pun
*
* https://github.com/andrewmichaelsmith/shoutbox_pun
*
*
* Copyright (c) 2012 Andrew Smith
*
* Dual licensed under the MIT and GPL licenses:
*   http://www.opensource.org/licenses/mit-license.php
*   http://www.gnu.org/licenses/gpl.html
*/
if (!defined('FORUM')) die();

?>