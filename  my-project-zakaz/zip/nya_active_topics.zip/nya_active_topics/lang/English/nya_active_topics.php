<?php

if (!defined('FORUM')) die();

$lang_active_topics = array(
	'Active topics'			=> 'Active Topics',
	'Active topics setting' => 'Active topics shown',
);
