<?php

if (!defined('FORUM')) die();

$lang_active_topics = array(
	'Active topics'			=> 'Активные и выделенные темы форума ',
	'Active topics setting' => 'Активных тем на главной',
);
